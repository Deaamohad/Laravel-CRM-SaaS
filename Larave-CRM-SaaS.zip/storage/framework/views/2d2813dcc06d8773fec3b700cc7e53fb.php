<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['type' => 'success', 'message']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['type' => 'success', 'message']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $bgColor = $type === 'success' ? 'bg-green-50' : 'bg-red-50';
    $borderColor = $type === 'success' ? 'border-green-400' : 'border-red-400';
    $textColor = $type === 'success' ? 'text-green-700' : 'text-red-700';
    $iconColor = $type === 'success' ? 'text-green-400' : 'text-red-400';
    $icon = $type === 'success' 
        ? '<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>'
        : '<path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L10 11.414l2.707-2.707a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>';
?>

<div class="mb-6 <?php echo e($bgColor); ?> border-l-4 <?php echo e($borderColor); ?> p-4 rounded-md shadow-sm">
    <div class="flex">
        <div class="flex-shrink-0">
            <svg class="h-5 w-5 <?php echo e($iconColor); ?>" fill="currentColor" viewBox="0 0 20 20">
                <?php echo $icon; ?>

            </svg>
        </div>
        <div class="ml-3">
            <p class="text-sm <?php echo e($textColor); ?> font-medium"><?php echo e($message); ?></p>
        </div>
    </div>
</div><?php /**PATH C:\Users\x2de5\Desktop\Laravel\Larave-CRM-SaaS\resources\views/components/flash-message.blade.php ENDPATH**/ ?>